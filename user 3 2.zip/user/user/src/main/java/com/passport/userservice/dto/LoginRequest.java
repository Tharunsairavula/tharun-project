package com.passport.userservice.dto;

import jakarta.persistence.Column;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginRequest {
	@Column(nullable = false)
	private String email;

	@Column(nullable = false)
	private String password;
}
