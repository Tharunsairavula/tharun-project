package com.passport.userservice.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.passport.userservice.dto.ApplyDTO;
import com.passport.userservice.dto.DeliveryDTO;
import com.passport.userservice.dto.EnquiryDTO;
import com.passport.userservice.feign.ApplyFeignClient;
import com.passport.userservice.feign.DeliveryFeignClient;
import com.passport.userservice.feign.EnquiryFeignClient;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/user") // The name of the service to be called
@Validated
public class UserController {

	@Autowired
	private ApplyFeignClient applyFeignClient;

	@Autowired
	private DeliveryFeignClient deliveryFeignClient;

	@Autowired
	private EnquiryFeignClient enquiryFeignClient;

	@GetMapping("/HOMEPAGE")
	public String getUserDashboard() {
		return "User Dashboard - Only users can access";
	}

	@PostMapping("/api/applications/create")
	@PreAuthorize("hasAuthority('USER')")
	public ApplyDTO createApplication(@RequestBody @Valid ApplyDTO applydto) {
		return applyFeignClient.applyForPassport(applydto);
	}

	@PutMapping("/api/applications/{userId}")
	@PreAuthorize("hasAuthority('USER')")
	public ApplyDTO updateApplication(@PathVariable Long userId, @RequestBody ApplyDTO applydto) {
		return applyFeignClient.updateApplication(userId, applydto);
	}

	@GetMapping("/api/deliveries/{userId}")
	@PreAuthorize("hasAuthority('USER')")
	public DeliveryDTO getDeliveryByuserId(@PathVariable Long userId) {
		return deliveryFeignClient.getDeliveryByuserId(userId);
	}

	@PostMapping("/api/enquiries/add")
	@PreAuthorize("hasAuthority('USER')")
	public String addEnquiry(@RequestBody @Valid EnquiryDTO enquiryDTO) {
		return enquiryFeignClient.addEnquiry(enquiryDTO);
	}

	@DeleteMapping("/api/enquiries/{userId}")
	@PreAuthorize("hasAuthority('USER')")
	public String deleteEnquiry(@PathVariable Long userId) {
		return enquiryFeignClient.deleteEnquiry(userId);
	}

}
