package com.passport.userservice.exception;

public class AgeNotValidException extends RuntimeException {

    public AgeNotValidException(String message) {
        super(message);
    }
}
