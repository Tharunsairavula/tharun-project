package com.passport.userservice.dto;

import java.time.LocalDate;
import java.time.Period;
import com.fasterxml.jackson.annotation.JsonFormat;

import org.springframework.format.annotation.DateTimeFormat;

import com.passport.userservice.exception.AgeNotValidException;

import jakarta.persistence.Column;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApplyDTO {

	private Long applicationNumber;

	@NotNull(message = "User ID cannot be null.")
	private Long userId;

	@NotBlank(message = "Name cannot be blank.")
	@Size(min = 3, max = 100, message = "Name must be between 3 and 100 characters.")
	@Column(length = 30, nullable = false)
	private String name;

	@NotBlank(message = "Gender cannot be blank.")
	private String gender;

	@NotBlank(message = "qualification cannot be blank.")
	private String qualification;

	//@DateTimeFormat(pattern = "yyyy-MM-dd")
	@NotNull(message = "Date of birth cannot be null.")
	@Past(message = "Date of birth must be in the past.")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate dob;

	@NotBlank(message = "place of birth cannot be blank.")
	private String placeOfBirth;

	private String status;

	@NotBlank(message = "Payment status cannot be blank.")
	private String paymentStatus;

	@NotBlank(message = "Delivery address cannot be blank.")
	@Size(max = 255, message = "Delivery address must not exceed 255 characters.")
	private String deliveryAddress;

	private String deliveryStatus;

	private LocalDate createdAt;

	private LocalDate updatedAt;
	
	public void validateUnder18() {
        if (dob != null) {
            int age = Period.between(dob, LocalDate.now()).getYears();
            if (age < 18) {
                throw new AgeNotValidException("User must be at least 18 years old.");
            }
        }
    }
	
}
