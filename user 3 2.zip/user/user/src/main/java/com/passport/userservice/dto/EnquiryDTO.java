package com.passport.userservice.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EnquiryDTO {

	private Integer enquiryId;

	@NotNull(message = "UserId is required")
	private Long userId;

	@NotNull(message = "Enquiry Date is required")
	private LocalDate enquiryDate;

	private String enquiryStatus;

	@NotBlank(message = "Description cannot be blank")
	private String enquiryDescription;

}
