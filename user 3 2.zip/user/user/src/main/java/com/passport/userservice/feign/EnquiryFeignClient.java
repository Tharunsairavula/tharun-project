package com.passport.userservice.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.passport.userservice.dto.EnquiryDTO;
import com.passport.userservice.exception.EnquiryNotFoundException;

import jakarta.validation.Valid;

@FeignClient("ENQUIRYSERVICE")
public interface EnquiryFeignClient {

	@GetMapping("/api/enquiries/getall")
	public List<EnquiryDTO> getAllEnquiries();

	@GetMapping("/api/enquiries/{userId}")
	public EnquiryDTO getEnquiryByuserId(@PathVariable Long userId) throws EnquiryNotFoundException;

	@PostMapping("/api/enquiries/add")
	public String addEnquiry(@Valid @RequestBody EnquiryDTO enquiryDTO);

	@PutMapping("/api/enquiries/{userId}/status")
	public String updateEnquiryStatus(@PathVariable Long userId, @RequestParam String status);

	@DeleteMapping("/api/enquiries/{userId}")
	public String deleteEnquiry(@PathVariable Long userId);

}
