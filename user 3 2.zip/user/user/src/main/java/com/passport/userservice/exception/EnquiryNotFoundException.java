package com.passport.userservice.exception;

public class EnquiryNotFoundException extends RuntimeException {

	public EnquiryNotFoundException(String message) {
		super(message);
	}
}
