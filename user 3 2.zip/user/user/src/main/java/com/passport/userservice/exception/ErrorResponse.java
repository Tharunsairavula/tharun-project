package com.passport.userservice.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
 
public class ErrorResponse {

	 private String errorMessage;
	    private LocalDateTime dateTime;
	    private HttpStatus statusCode;

	    // Getters and Setters
	    public String getErrorMessage() {
	        return errorMessage;
	    }

	    public void setErrorMessage(String errorMessage) {
	        this.errorMessage = errorMessage;
	    }

	    public LocalDateTime getDateTime() {
	        return dateTime;
	    }

	    public void setDateTime(LocalDateTime dateTime) {
	        this.dateTime = dateTime;
	    }

	    public HttpStatus getStatusCode() {
	        return statusCode;
	    }

	    public void setStatusCode(HttpStatus statusCode) {
	        this.statusCode = statusCode;
	    }

	    // Constructor
	    public ErrorResponse() {
	        super();
	    }
	
}

