package com.passport.userservice.exception;

public class DeliveryNotFoundException extends Exception {

	public DeliveryNotFoundException(String message) {
		super(message);
	}
}
