package com.passport.userservice.entity;

public enum Role {

	ADMIN, USER;
}
