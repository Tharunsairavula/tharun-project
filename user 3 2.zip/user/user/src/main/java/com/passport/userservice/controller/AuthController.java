package com.passport.userservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import com.passport.userservice.dto.LoginRequest;
import com.passport.userservice.dto.LoginResponse;
import com.passport.userservice.dto.UserRequestDTO;
import com.passport.userservice.dto.UserResponseDTO;
import com.passport.userservice.entity.Role;
import com.passport.userservice.entity.User;
import com.passport.userservice.exception.UserAlreadyexistsException;
import com.passport.userservice.repository.UserRepository;
import com.passport.userservice.security.JwtUtil;

import jakarta.validation.Valid;

import java.time.LocalDateTime;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    public AuthController(UserRepository userRepository, PasswordEncoder passwordEncoder, JwtUtil jwtUtil) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }

    // REGISTER
    @PostMapping("/register")
    public ResponseEntity<UserResponseDTO> register(@RequestBody @Valid UserRequestDTO userRequestDTO) {
        logger.info("Registration attempt for email: {}", userRequestDTO.getEmail());

        if (userRepository.findByEmail(userRequestDTO.getEmail()).isPresent()) {
            logger.error("User already exists with email: {}", userRequestDTO.getEmail());
            throw new UserAlreadyexistsException("User already exists");
        }

        User user = new User();
        user.setName(userRequestDTO.getName());
        user.setEmail(userRequestDTO.getEmail());
        user.setPassword(passwordEncoder.encode(userRequestDTO.getPassword())); // Encrypt password
        user.setRole(Role.valueOf(userRequestDTO.getRole().toUpperCase())); // Convert role to enum

        userRepository.save(user);
        logger.info("User successfully registered: {}", userRequestDTO.getEmail());

        UserResponseDTO userResponseDTO = new UserResponseDTO();
        userResponseDTO.setMessage("User registered successfully");
        userResponseDTO.setName(userRequestDTO.getName());
        userResponseDTO.setEmail(userRequestDTO.getEmail());
        return new ResponseEntity<>(userResponseDTO, HttpStatus.OK);
    }

    // Admin LOGIN
    @PostMapping("/admin/login")
    public ResponseEntity<LoginResponse> adminLogin(@RequestBody LoginRequest loginRequest) {
        logger.info("Admin login attempt for email: {}", loginRequest.getEmail());

        Optional<User> userOptional = userRepository.findByEmail(loginRequest.getEmail());

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            if (passwordEncoder.matches(loginRequest.getPassword(), user.getPassword()) && user.getRole() == Role.ADMIN) {
                String token = jwtUtil.generateToken(user.getEmail());
                logger.info("Admin login successful for email: {}", loginRequest.getEmail());
                String message = "Admin login successful. Token: " + token + "\nRedirect to: /api/admin/homepage";
                LoginResponse loginResponse = new LoginResponse();
                loginResponse.setMessage(message);
                loginResponse.setDateTime(LocalDateTime.now());
                loginResponse.setStatusCode(HttpStatus.OK);
                return new ResponseEntity<>(loginResponse, HttpStatus.OK);
            }
        }

        // Invalid credentials
        logger.warn("Invalid admin login attempt for email: {}", loginRequest.getEmail());
        LoginResponse loginResponse = new LoginResponse();
        loginResponse.setMessage("Invalid admin credentials");
        loginResponse.setDateTime(LocalDateTime.now());
        loginResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        return new ResponseEntity<>(loginResponse, HttpStatus.BAD_REQUEST);
    }

    // User LOGIN
    @PostMapping("/user/login")
    public ResponseEntity<LoginResponse> userLogin(@RequestBody LoginRequest loginRequest) {
        logger.info("User login attempt for email: {}", loginRequest.getEmail());

        Optional<User> userOptional = userRepository.findByEmail(loginRequest.getEmail());

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            if (passwordEncoder.matches(loginRequest.getPassword(), user.getPassword()) && user.getRole() == Role.USER) {
                String token = jwtUtil.generateToken(user.getEmail());
                logger.info("User login successful for email: {}", loginRequest.getEmail());
                String message = "User login successful. Token: " + token + "\nRedirect to: /api/user/homepage";
                LoginResponse loginResponse = new LoginResponse();
                loginResponse.setMessage(message);
                loginResponse.setDateTime(LocalDateTime.now());
                loginResponse.setStatusCode(HttpStatus.OK);
                return new ResponseEntity<>(loginResponse, HttpStatus.OK);
            }
        }

        // Invalid credentials
        logger.warn("Invalid user login attempt for email: {}", loginRequest.getEmail());
        LoginResponse loginResponse = new LoginResponse();
        loginResponse.setMessage("Invalid user credentials");
        loginResponse.setDateTime(LocalDateTime.now());
        loginResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        return new ResponseEntity<>(loginResponse, HttpStatus.BAD_REQUEST);
    }
}
