package com.passport.userservice.feign;

import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.passport.userservice.dto.ApplyDTO;

import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.validation.Valid;

@FeignClient("APPLY")
public interface ApplyFeignClient {

	// Create a new application
	@PostMapping("/api/applications/apply")
	ApplyDTO applyForPassport(@RequestBody @Valid ApplyDTO apply);

	// Get all applications
	@GetMapping("/api/applications/getall")
	List<ApplyDTO> getAllApplications();

	// Get application details by ID
	@GetMapping("/api/applications/{userId}")
	public ApplyDTO getApplicationByUserId(@PathVariable("userId") Long userId);

	// Update status of the application
	@PutMapping("/api/applications/{userId}/status")
	public ApplyDTO updateApplicationStatus(@PathVariable("userId") Long userId, @RequestParam String status);

	@PutMapping("/api/applications/{userId}")
	public ApplyDTO updateApplication(@PathVariable("userId") Long userId, @RequestBody ApplyDTO applyDTO);


}