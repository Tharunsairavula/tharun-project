package com.passport.userservice.exception;

public class DuplicateApplicationException extends RuntimeException{
	public DuplicateApplicationException(String message) {
		super(message);
	}
}

