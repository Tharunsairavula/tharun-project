package com.passport.userservice.exception;

public class MessagingException extends Exception {

	public MessagingException(String message) {
		super(message);
	}

}
