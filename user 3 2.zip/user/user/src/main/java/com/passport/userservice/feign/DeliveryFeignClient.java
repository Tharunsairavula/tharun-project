package com.passport.userservice.feign;

import org.springframework.cloud.openfeign.FeignClient;

import org.springframework.web.bind.annotation.*;

import com.passport.userservice.dto.DeliveryDTO;

import jakarta.validation.Valid;

import java.util.List;

@FeignClient("DELIVERYSERVICE")
public interface DeliveryFeignClient {

	// Create a new delivery
	@PostMapping("/api/deliveries/create")
	DeliveryDTO createDelivery(@RequestBody @Valid DeliveryDTO deliverydto);

	// Get all deliveries
	@GetMapping("/api/deliveries/getall")
	List<DeliveryDTO> getAllDeliveries();

	// Get a delivery by number
	@GetMapping("/api/deliveries/{userId}")
	DeliveryDTO getDeliveryByuserId(@PathVariable Long userId);

	// Update a delivery
	@PutMapping("/api/deliveries/{userId}")
	DeliveryDTO updateDelivery(@PathVariable Long userId, @RequestBody DeliveryDTO deliverydto);

	// Delete a delivery
	@DeleteMapping("/api/deliveries/{userId}")
	String deleteDelivery(@PathVariable Long userId);
}