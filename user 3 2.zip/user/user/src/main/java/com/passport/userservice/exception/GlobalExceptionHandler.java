package com.passport.userservice.exception;

import java.time.LocalDateTime;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import feign.FeignException;


@RestControllerAdvice
public class GlobalExceptionHandler {

	private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	// Method to generate error response
    private ErrorResponse generateErrorResponse(String errorMessage, HttpStatus status) {
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setErrorMessage(errorMessage);
        errorResponse.setDateTime(LocalDateTime.now());
         errorResponse.setStatusCode(status);
        return errorResponse;
    }
    


    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidationExceptions(MethodArgumentNotValidException ex) {
        List<FieldError> fieldErrors = ex.getBindingResult().getFieldErrors();
        String errorMessages = fieldErrors.stream()
                .map(fieldError -> fieldError.getDefaultMessage())
                .collect(Collectors.joining(", "));

        ErrorResponse errorResponse = generateErrorResponse("Validation failed: " + errorMessages, HttpStatus.BAD_REQUEST);

        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
    }
    @ExceptionHandler(DuplicateApplicationException.class)
    public ResponseEntity<ErrorResponse> handleDuplicateApplication(DuplicateApplicationException ex) {
        // Generate custom error message for duplicate application
        String errorMessage = ex.getMessage();
        // You could set the status to CONFLICT (409)
        ErrorResponse errorResponse = generateErrorResponse(errorMessage, HttpStatus.CONFLICT);
        return new ResponseEntity<>(errorResponse, HttpStatus.CONFLICT);
    }



    @ExceptionHandler(UserAlreadyexistsException.class)
    public ResponseEntity<ErrorResponse> handleUserAlreadyExists(UserAlreadyexistsException ex) {
        ErrorResponse errorResponse = generateErrorResponse(ex.getMessage(), HttpStatus.BAD_REQUEST);
        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(DeliveryNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleDeliveryNotFoundException(DeliveryNotFoundException ex) {
        ErrorResponse errorResponse = generateErrorResponse(ex.getMessage(), HttpStatus.NOT_FOUND);
        return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
    }
    

  
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<String> handleJsonParseException(HttpMessageNotReadableException ex) {
        // Custom error message or logging logic
        String errorMessage = "Invalid date format. Please use the correct format 'yyyy-MM-dd'.";
        return new ResponseEntity<>(errorMessage, HttpStatus.BAD_REQUEST);
    }
    
   


    
    @ExceptionHandler(FeignException.BadRequest.class)
    public ResponseEntity<ErrorResponse> handleFeignBadRequest(FeignException.BadRequest ex) {
        if (ex.getMessage().contains("User must be at least 18 years old")) {
            String errorMessage = "User must be at least 18 years old.";
            ErrorResponse errorResponse = generateErrorResponse(errorMessage, HttpStatus.BAD_REQUEST);
            return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
        }
        // Handle other BadRequest errors
        return new ResponseEntity<>(generateErrorResponse("Bad Request", HttpStatus.BAD_REQUEST), HttpStatus.BAD_REQUEST);
    }
    
    @ExceptionHandler(FeignException.NotFound.class)
  //  @ResponseStatus(HttpStatus.BAD_REQUEST) // or whatever status fits your needs
    public ResponseEntity<ErrorResponse> handleFeignNotFoundException(FeignException.NotFound exception) {
    	
        if (exception.getMessage().contains("User must be at least 18 years old")) {

    	System.out.println("Caught FeignException: " + exception.getMessage());

        // Create the error message
        String errorMessage = "An application already exists for the user.";
        
        // Generate the error response with a proper error message and BAD_REQUEST status
        ErrorResponse errorResponse = generateErrorResponse(errorMessage, HttpStatus.BAD_REQUEST);

        // Return ResponseEntity with the error response and status
        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
        }
        if (exception.getMessage().contains("Enquiry ID: 14 not found.")) {
        	 String errorMessage = "Enquiry ID: 14 not found.";
             
             // Generate the error response with a proper error message and BAD_REQUEST status
             ErrorResponse errorResponse = generateErrorResponse(errorMessage, HttpStatus.BAD_REQUEST);

             // Return ResponseEntity with the error response and status
             return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);

        	
        }
        if (exception.getMessage().contains("Delivery not found")) {
       	 String errorMessage = "Delivery not found.";
            
            // Generate the error response with a proper error message and BAD_REQUEST status
            ErrorResponse errorResponse = generateErrorResponse(errorMessage, HttpStatus.BAD_REQUEST);

            // Return ResponseEntity with the error response and status
            return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);

       	
       }

        return new ResponseEntity<>(generateErrorResponse("Bad Request", HttpStatus.BAD_REQUEST), HttpStatus.BAD_REQUEST);

      }
    
    
   

}
