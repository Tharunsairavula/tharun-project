package com.passport.userservice.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeliveryDTO {
	private Integer deliveryNumber;

	@NotNull(message = "userId is required")
	private Long userId;

	@NotBlank(message = "Delivery person name is required")
	private String deliveryPersonName;

	@Pattern(regexp = "^\\d{10}$", message = "Phone number must be 10 digits")
	private String deliveryPersonPhoneNumber;

	private LocalDate deliveryDate;

	private String deliveryStatus;

	@NotEmpty(message = "Delivery address is required")
	@Size(min = 5, max = 100, message = "Address must be between 5 and 100 characters")
	private String deliveryAddress;

}
