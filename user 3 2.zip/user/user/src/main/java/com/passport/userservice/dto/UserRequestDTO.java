package com.passport.userservice.dto;

import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import jakarta.persistence.Column;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class UserRequestDTO {
	@Column(nullable = false)
    @NotNull(message = "Name cannot be null")
    private String name;
 
    @Column(unique = true, nullable = false)
    @NotNull(message = "Email cannot be null")
    @Email(message = "Email should have @ and .com")
    @Pattern(regexp = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.com$", message = "Invalid email format")
    private String email;
 
    @Column(nullable = false)
    @NotNull(message = "Password cannot be null")
    @Size(min = 8, max = 12, message="password should be eight or 16 characters")
    private String password;
 
    @Column(nullable = false)
    @NotNull(message = "Role cannot be null")
    private String role;
}
