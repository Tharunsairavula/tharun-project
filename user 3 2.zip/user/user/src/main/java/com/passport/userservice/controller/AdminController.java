package com.passport.userservice.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.passport.userservice.dto.ApplyDTO;
import com.passport.userservice.dto.DeliveryDTO;
import com.passport.userservice.dto.EnquiryDTO;
import com.passport.userservice.feign.ApplyFeignClient;
import com.passport.userservice.feign.DeliveryFeignClient;
import com.passport.userservice.feign.EnquiryFeignClient;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/admin")   // The name of the service to be called
@Validated
public class AdminController {

	@Autowired
	private ApplyFeignClient applyFeignClient;

	@Autowired
	private DeliveryFeignClient deliveryFeignClient;

	@Autowired
	private EnquiryFeignClient enquiryFeignClient;

	@GetMapping("/HOMEPAGE")
	public String getAdminDashboard() {
		return "Admin Dashboard - Only accessible by Admins";
	}

	@GetMapping("/api/applications/getall")
	@PreAuthorize("hasAuthority('ADMIN')")
	List<ApplyDTO> getAllApplications() {
		return applyFeignClient.getAllApplications();
	}

	@PutMapping("/api/applications/{userId}/status")
	@PreAuthorize("hasAuthority('ADMIN')")
	public ApplyDTO updateApplicationStatus(@PathVariable Long userId, @RequestParam String status) {
		return applyFeignClient.updateApplicationStatus(userId, status);
	}

// Admin: Manage Deliveries
	@PostMapping("/api/deliveries/create")
	@PreAuthorize("hasAuthority('ADMIN')")
	public DeliveryDTO createDelivery(@RequestBody @Valid DeliveryDTO deliverydto) {
		return deliveryFeignClient.createDelivery(deliverydto);
	}

	@GetMapping("/api/deliveries/getall")
	@PreAuthorize("hasAuthority('ADMIN')")
	public List<DeliveryDTO> getAllDeliveries() {
		return deliveryFeignClient.getAllDeliveries();
	}

	@PutMapping("/api/deliveries/{userId}")
	@PreAuthorize("hasAuthority('ADMIN')")
	public DeliveryDTO updateDelivery(@PathVariable Long userId, @RequestBody DeliveryDTO deliverydto) {

		return deliveryFeignClient.updateDelivery(userId, deliverydto);
	}

	@DeleteMapping("/api/deliveries/{userId}")
	@PreAuthorize("hasAuthority('ADMIN')")
	public String deleteDelivery(@PathVariable Long userId) {
		return deliveryFeignClient.deleteDelivery(userId);
	}

	@GetMapping("/api/enquiries/getall")
	@PreAuthorize("hasAuthority('ADMIN')")
	public List<EnquiryDTO> getAllEnquiries() {
		return enquiryFeignClient.getAllEnquiries();
	}

	@GetMapping("/api/enquiries/{userId}")
	@PreAuthorize("hasAuthority('ADMIN')")
	public EnquiryDTO getEnquiryByuserId(@PathVariable Long userId) {
		return enquiryFeignClient.getEnquiryByuserId(userId);
	}

	@PutMapping("/api/enquiries/{userId}/status")
	@PreAuthorize("hasAuthority('ADMIN')")
	public String updateEnquiryStatus(@PathVariable Long userId, @RequestParam String status) {
		return enquiryFeignClient.updateEnquiryStatus(userId, status);
	}

}
