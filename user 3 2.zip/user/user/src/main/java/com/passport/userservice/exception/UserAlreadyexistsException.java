package com.passport.userservice.exception;

public class UserAlreadyexistsException extends RuntimeException{

	public UserAlreadyexistsException(String message) {
		super(message);
	}
}
