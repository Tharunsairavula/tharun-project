package com.passport.userservice.service;

import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.passport.userservice.entity.User;
import com.passport.userservice.repository.UserRepository;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class UserServiceTest {

	@Mock
	private UserRepository userRepository;

	@Mock
	private PasswordEncoder passwordEncoder;

	@InjectMocks
	private UserService userService;

	private User user;
	private String validEmail;
	private String validPassword;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);

		// Mock data for the user
		validEmail = "test@example.com";
		validPassword = "password123";

		user = new User();
		user.setEmail(validEmail);
		user.setPassword(validPassword); // Assume this is the hashed password

		// Mock behavior of the UserRepository and PasswordEncoder
		Mockito.when(userRepository.findByEmail(validEmail)).thenReturn(Optional.of(user));
	}

	@Test
	void validateUser_ValidEmailAndPassword() {
		// Given
		Mockito.when(passwordEncoder.matches(validPassword, user.getPassword())).thenReturn(true);

		// When
		User result = userService.validateUser(validEmail, validPassword);

		// Then
		assertNotNull(result);
		assertEquals(validEmail, result.getEmail());
	}

	@Test
	void validateUser_InvalidEmail() {
		// Given
		String invalidEmail = "invalid@example.com";
		Mockito.when(userRepository.findByEmail(invalidEmail)).thenReturn(Optional.empty());

		// When
		User result = userService.validateUser(invalidEmail, validPassword);

		// Then
		assertNull(result); // Should return null when the email does not exist
	}

	@Test
	void validateUser_InvalidPassword() {
		// Given
		String wrongPassword = "wrongPassword123";
		Mockito.when(passwordEncoder.matches(wrongPassword, user.getPassword())).thenReturn(false);

		// When
		User result = userService.validateUser(validEmail, wrongPassword);

		// Then
		assertNull(result); // Should return null if the password does not match
	}

	@Test
	void validateUser_PasswordMatches() {
		// Given
		Mockito.when(passwordEncoder.matches(validPassword, user.getPassword())).thenReturn(true);

		// When
		User result = userService.validateUser(validEmail, validPassword);

		// Then
		assertNotNull(result);
		assertEquals(validEmail, result.getEmail());
	}
}