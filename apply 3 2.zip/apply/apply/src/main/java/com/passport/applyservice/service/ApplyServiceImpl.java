package com.passport.applyservice.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.passport.applyservice.dto.ApplyDTO;
import com.passport.applyservice.entity.Apply;
import com.passport.applyservice.exception.DuplicateApplicationException;
import com.passport.applyservice.exception.IdNotFoundException;
import com.passport.applyservice.mapper.ApplyMapper;
import com.passport.applyservice.repository.ApplyRepository;

import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ApplyServiceImpl implements ApplyService {

	 private static final Logger logger = LoggerFactory.getLogger(ApplyServiceImpl.class);

	    @Autowired
	    private ApplyRepository applyRepository;

	    @Override
	    public ApplyDTO applyForPassport(ApplyDTO applyDTO) throws DuplicateApplicationException {
	        logger.info("Creating new application with details: {}", applyDTO);

	        // Check if an application already exists for this user
	        Optional<Apply> existingApplication = applyRepository.findByUserId(applyDTO.getUserId());
	        if (existingApplication.isPresent()) {
	            logger.error("Application already exists for user with ID: {}", applyDTO.getUserId());
	            throw new DuplicateApplicationException("An application already exists for user ID: " + applyDTO.getUserId());
	        }

	        // Set initial application status and timestamps
	        applyDTO.setDeliveryStatus("not delivered");
	        applyDTO.setStatus("pending");
	        applyDTO.setCreatedAt(LocalDate.now());
	        applyDTO.setUpdatedAt(LocalDate.now());

	        Apply apply = ApplyMapper.mapToApply(applyDTO);
	        Apply savedApply = applyRepository.save(apply);

	        logger.info("Application created successfully with ID: {}", savedApply.getApplicationNumber());

	        return ApplyMapper.mapToApplyDTO(savedApply);
	    }

	    @Override
	    public List<ApplyDTO> getAllApplications() {
	        logger.info("Fetching all applications");

	        List<Apply> applications = applyRepository.findAll();

	        // Convert the list of Apply entities to ApplyDTOs
	        List<ApplyDTO> applicationDTOs = applications.stream()
	                .map(ApplyMapper::mapToApplyDTO)
	                .collect(Collectors.toList());

	        logger.info("Fetched {} applications", applicationDTOs.size());
	        return applicationDTOs;
	    }

	  

	    @Override
	    public ApplyDTO updateApplication(Long userId, ApplyDTO applyDTO) throws IdNotFoundException {
	        logger.info("Updating application for user with ID: {}", userId);

	        // Find the application associated with the userId
	        Optional<Apply> apply = applyRepository.findByUserId(userId);

	        // If no application is found, throw an exception
	        if (!apply.isPresent()) {
	            logger.error("Application not found for user with ID: {}", userId);
	            throw new IdNotFoundException("Application not found for user ID: " + userId);
	        }

	        // Map ApplyDTO to Apply entity
	        Apply updatedApply = ApplyMapper.mapToApply(applyDTO);
	        updatedApply.setApplicationNumber(apply.get().getApplicationNumber());  // Ensure correct ID is set for the update
	        updatedApply.setUpdatedAt(LocalDate.now());  // Set the updated timestamp

	        // Save the updated application
	        Apply savedApply = applyRepository.save(updatedApply);

	        logger.info("Application updated successfully for user with ID: {}", savedApply.getApplicationNumber());
	        return ApplyMapper.mapToApplyDTO(savedApply);
	    }

	    @Override
	    public ApplyDTO updateApplicationStatus(Long userId, String status) throws IdNotFoundException {
	        logger.info("Updating status for application with user ID: {} to {}", userId, status);

	        // Find the application by userId
	        Optional<Apply> application = applyRepository.findByUserId(userId);

	        // Check if the application is not found, and throw the exception manually
	        if (!application.isPresent()) {
	            logger.error("Application not found with user ID: {}", userId);
	            throw new IdNotFoundException("Application not found for user ID: " + userId);
	        }

	        // Update the status of the application
	        Apply updatedApply = application.get();
	        updatedApply.setStatus(status);
	        Apply savedApply = applyRepository.save(updatedApply);

	        logger.info("Application status updated successfully for user with ID: {}", savedApply.getApplicationNumber());

	        // Return the updated DTO
	        return ApplyMapper.mapToApplyDTO(savedApply);
	    }

	    public boolean deleteApplication(Long applicationNumber) {
	    	logger.info("Entering cancelApplication method with applicationId: {}", applicationNumber);

	        Optional<Apply> applyOptional = applyRepository.findById(applicationNumber);
	        if (applyOptional.isPresent()) {
	            Apply apply = applyOptional.get();
	            applyRepository.deleteById(applicationNumber);
	            return true;
	        } else {
	            logger.warn("No application found to cancel for applicationId: {}", applicationNumber);
	            throw new IdNotFoundException("Application not found with applicationId: " + applicationNumber);
	        }
 }

		@Override
		public ApplyDTO getApplicationByUserId(Long userId) {
			logger.info("Fetching application for user with ID: {}", userId);

	        Optional<Apply> application = applyRepository.findByUserId(userId);

	        // If no application is found for the userId, throw an exception
	        if (!application.isPresent()) {
	            logger.error("Application not found for user with ID: {}", userId);
	            throw new IdNotFoundException("Application not found for user ID: " + userId);
	        }

	        logger.info("Application found for user with ID: {}", userId);
	        return ApplyMapper.mapToApplyDTO(application.get());
		}
	
}