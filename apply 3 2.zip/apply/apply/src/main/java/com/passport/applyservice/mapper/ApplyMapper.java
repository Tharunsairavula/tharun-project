package com.passport.applyservice.mapper;

import com.passport.applyservice.dto.ApplyDTO;

import com.passport.applyservice.entity.Apply;

public class ApplyMapper {

	public static Apply mapToApply(ApplyDTO applyDTO) {
		return new Apply(applyDTO.getApplicationNumber(), applyDTO.getUserId(), applyDTO.getName(), applyDTO.getGender(),
				applyDTO.getDob(), applyDTO.getPlaceOfBirth(), applyDTO.getStatus(), applyDTO.getQualification(),
				applyDTO.getPaymentStatus(), applyDTO.getDeliveryAddress(), applyDTO.getDeliveryStatus(),
				applyDTO.getCreatedAt(), applyDTO.getUpdatedAt());
	}

	// Convert Apply entity to ApplyDTO
	public static ApplyDTO mapToApplyDTO(Apply apply) {
		return new ApplyDTO(apply.getApplicationNumber(), apply.getUserId(), apply.getName(), apply.getGender(), apply.getDob(),
				apply.getPlaceOfBirth(), apply.getStatus(), apply.getQualification(), apply.getPaymentStatus(),
				apply.getDeliveryAddress(), apply.getDeliveryStatus(), apply.getCreatedAt(), apply.getUpdatedAt());
	}
}
