package com.passport.applyservice.dto;

import java.time.LocalDate;
import java.time.Period;

import org.springframework.format.annotation.DateTimeFormat;

import com.passport.applyservice.exception.AgeNotValidException;

import jakarta.persistence.Column;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApplyDTO {

	private Long applicationNumber;

	@NotNull(message = "User ID cannot be null.")
	private Long userId;

	@NotBlank(message = "Name cannot be blank.")
	@Size(min = 3, max = 100, message = "Name must be between 3 and 100 characters.")
	@Column(length = 30, nullable = false)
	private String name;

	@NotBlank(message = "Gender cannot be blank.")
	private String gender;

	@NotNull(message = "Date of birth cannot be null.")
	@Past(message = "Date of birth must be in the past.")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dob;

	@NotBlank(message = "place of birth cannot be blank.")
	private String placeOfBirth;

	private String status;

	@NotBlank(message = "qualification cannot be blank.")
	private String qualification;

	@NotBlank(message = "Payment status cannot be blank.")
	private String paymentStatus;

	@NotBlank(message = "Delivery address cannot be blank.")
	@Size(max = 255, message = "Delivery address must not exceed 255 characters.")
	
	private String deliveryAddress;

	private String deliveryStatus;

	private LocalDate createdAt;

	private LocalDate updatedAt;
	
	// Method to check if the user is under 18
    public void validateUnder18() {
        if (dob != null) {
            int age = Period.between(dob, LocalDate.now()).getYears();
            if (age < 18) {
                throw new AgeNotValidException("User must be at least 18 years old.");
            }
        }
    }
	
}
