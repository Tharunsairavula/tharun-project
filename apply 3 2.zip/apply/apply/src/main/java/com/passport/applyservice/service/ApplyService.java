package com.passport.applyservice.service;

import java.util.List;
import com.passport.applyservice.dto.ApplyDTO;

public interface ApplyService {

	ApplyDTO applyForPassport(ApplyDTO applyDTO);

	// Method to get all applications and return a list of ApplyDTOs
	List<ApplyDTO> getAllApplications();

	// Method to get an application by ID and return ApplyDTO, or null if not found
	ApplyDTO getApplicationByUserId(Long userId);

	// Method to update an application and return the updated ApplyDTO
	ApplyDTO updateApplication(Long userId, ApplyDTO applyDTO);

	// Method to update the application status and return the updated ApplyDTO
	ApplyDTO updateApplicationStatus(Long userId, String status);

}
