package com.passport.applyservice.exception;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;



@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(IdNotFoundException.class)
	public ResponseEntity<ErrorMessage> handleIdNotFoundException(IdNotFoundException ex) {
		// Create a custom error message with the exception message and a custom error
		// description
		ErrorMessage errorMessage = new ErrorMessage(ex.getMessage(), // Exception message (e.g., "ID not found")
				"The requested ID does not exist in the system." // Custom error description
		);

		// Return the error message along with HTTP status NOT_FOUND (404)
		return new ResponseEntity<>(errorMessage, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach(error -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }
	
	@ExceptionHandler(DuplicateApplicationException.class)
	public ResponseEntity<ErrorMessage> handleDuplicateApplicationException(DuplicateApplicationException ex) {
		// Create a custom error message with the exception message and a custom error
		ErrorMessage errorMessage = new ErrorMessage(ex.getMessage(), 
				"The requested ID does not exist in the system." 
		);

		// Return the error message along with HTTP status NOT_FOUND (404)
		return new ResponseEntity<>(errorMessage, HttpStatus.NOT_FOUND);
	}
	 @ExceptionHandler(AgeNotValidException.class)
	    @ResponseStatus(HttpStatus.BAD_REQUEST)
	    public ResponseEntity<String> handleAgeNotValidException(AgeNotValidException ex) {
	        return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
	    }

	@ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<String> handleJsonParseException(HttpMessageNotReadableException ex) {
        // Custom error message or logging logic
        String errorMessage = "Invalid date format. Please use the correct format 'yyyy-MM-dd'.";
        return new ResponseEntity<>(errorMessage, HttpStatus.BAD_REQUEST);
    }
	
	
	



}
