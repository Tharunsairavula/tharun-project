package com.passport.applyservice.controller;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import com.passport.applyservice.dto.ApplyDTO;
import com.passport.applyservice.service.ApplyService;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/applications")
@Validated
public class ApplyController {

	@Autowired
	private ApplyService applyService;

	// Create a new applicationa
	@PostMapping("/apply")
	public ResponseEntity<ApplyDTO> applyForPassport(@RequestBody @Valid ApplyDTO applyDTO) {
		log.info("Request to create application: {}", applyDTO);
		applyDTO.validateUnder18();
		ApplyDTO createdApplyDTO = applyService.applyForPassport(applyDTO);
		log.info("Created application: {}", createdApplyDTO);
		return new ResponseEntity<>(createdApplyDTO, HttpStatus.CREATED);
	}

	// Get all applications
	@GetMapping("/getall")
	public ResponseEntity<List<ApplyDTO>> getAllApplications() {
		log.info("Request to get all applications");
		List<ApplyDTO> applications = applyService.getAllApplications();
		log.info("Retrieved applications: {}", applications);
		return new ResponseEntity<>(applications, HttpStatus.OK);
	}

	// Get application details by ID
	@GetMapping("/{userId}")
	public ResponseEntity<ApplyDTO> getApplicationByUserId(@PathVariable("userId") Long userId) {
		log.info("Request to get application by Userid: {}", userId);
		ApplyDTO application = applyService.getApplicationByUserId(userId);
		if (application != null) {
			log.info("Found application: {}", application);
			return new ResponseEntity<>(application, HttpStatus.OK);
		} else {
			log.warn("Application with id {} not found", userId);
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	// Update application details
	@PutMapping("/{userId}")
	public ResponseEntity<ApplyDTO> updateApplication(@PathVariable("userId") Long userId,
			@RequestBody ApplyDTO applyDTO) {
		log.info("Request to update application with userid {}: {}", userId, applyDTO);
		ApplyDTO updatedApplyDTO = applyService.updateApplication(userId, applyDTO);
		if (updatedApplyDTO != null) {
			log.info("Updated application: {}", updatedApplyDTO);
			return new ResponseEntity<>(updatedApplyDTO, HttpStatus.OK);
		} else {
			log.warn("Application with id {} not found for update", userId);
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	// Update status of the application
	@PutMapping("/{userId}/status")
	public ResponseEntity<ApplyDTO> updateApplicationStatus(@PathVariable("userId") Long userId,
			@RequestParam String status) {
		log.info("Request to update status of application with id {} to: {}", userId, status);
		ApplyDTO updatedApplyDTO = applyService.updateApplicationStatus(userId, status);
		if (updatedApplyDTO != null) {
			log.info("Updated status of application: {}", updatedApplyDTO);
			return new ResponseEntity<>(updatedApplyDTO, HttpStatus.OK);
		} else {
			log.warn("Application with id {} not found for status update", userId);
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
}
