package com.passport.applyservice.entity;

import java.time.LocalDate;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor


public class Apply {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-generate the ID
	private Long applicationNumber;
	private Long userId;
	private String name;
	private String gender;
	private LocalDate dob;
	private String placeOfBirth;
	private String status;
	private String qualification;
	private String paymentStatus;
	private String deliveryAddress;
	private String deliveryStatus;
	private LocalDate createdAt;
	private LocalDate updatedAt;
}
