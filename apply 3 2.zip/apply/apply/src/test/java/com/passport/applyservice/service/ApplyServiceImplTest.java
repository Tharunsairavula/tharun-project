package com.passport.applyservice.service;

import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import com.passport.applyservice.dto.ApplyDTO;
import com.passport.applyservice.entity.Apply;
import com.passport.applyservice.exception.DuplicateApplicationException;
import com.passport.applyservice.exception.IdNotFoundException;
import com.passport.applyservice.repository.ApplyRepository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

public class ApplyServiceImplTest {

	 @Mock
	    private ApplyRepository applyRepository;

	    @InjectMocks
	    private ApplyServiceImpl applyService;

	    private ApplyDTO applyDTO;
	    private Apply apply;

	    @BeforeEach
	    void setUp() {
	        // Initialize mocks
	        MockitoAnnotations.openMocks(this);

	        // Setup mock data for ApplyDTO and Apply entity
	        applyDTO = new ApplyDTO();
	        applyDTO.setUserId(1L);
	        applyDTO.setStatus("pending");
	        applyDTO.setDeliveryStatus("not delivered");
	        applyDTO.setCreatedAt(LocalDate.now());
	        applyDTO.setUpdatedAt(LocalDate.now());

	        apply = new Apply();
	        apply.setApplicationNumber(1L);
	        apply.setUserId(1L);
	        apply.setStatus("pending");
	        apply.setDeliveryStatus("not delivered");
	        apply.setCreatedAt(LocalDate.now());
	        apply.setUpdatedAt(LocalDate.now());
	    }

	    // Test for applyForPassport - Duplicate application
	    @Test
	    void testApplyForPassport_Duplicate() throws DuplicateApplicationException {
	        // Mock the repository to return an existing application for the given user ID
	        when(applyRepository.findByUserId(anyLong())).thenReturn(Optional.of(apply));

	        // Assert that a DuplicateApplicationException is thrown
	        assertThrows(DuplicateApplicationException.class, () -> applyService.applyForPassport(applyDTO));

	        // Verify the repository interaction
	        verify(applyRepository, times(1)).findByUserId(anyLong());
	        verify(applyRepository, times(0)).save(any(Apply.class));
	    }

	    // Test for getAllApplications
	    @Test
	    void testGetAllApplications() {
	        Apply apply1 = new Apply();
	        apply1.setUserId(1L);
	        Apply apply2 = new Apply();
	        apply2.setUserId(2L);

	        // Mock the repository to return a list of applications
	        when(applyRepository.findAll()).thenReturn(List.of(apply1, apply2));

	        // Call the method
	        List<ApplyDTO> result = applyService.getAllApplications();

	        // Assert that the returned list is not empty
	        assertNotNull(result);
	        assertEquals(2, result.size());

	        // Verify the repository interaction
	        verify(applyRepository, times(1)).findAll();
	    }

	    // Test for getApplicationByUserId - Successful fetch
	    @Test
	    void testGetApplicationByUserId_Success() throws IdNotFoundException {
	        // Mock the repository to return an application for the given user ID
	        when(applyRepository.findByUserId(anyLong())).thenReturn(Optional.of(apply));

	        // Call the method
	        ApplyDTO result = applyService.getApplicationByUserId(1L);

	        // Assert that the result is not null and has the expected user ID
	        assertNotNull(result);
	        assertEquals(1L, result.getUserId());

	        // Verify the repository interaction
	        verify(applyRepository, times(1)).findByUserId(anyLong());
	    }

//	    // Test for getApplicationByUserId - Application not found
//	    @Test
//	    void testGetApplicationByUserId_NotFound() {
//	        // Mock the repository to return an empty Optional for the given user ID
//	        when(applyRepository.findByUserId(anyLong())).thenReturn(Optional.empty());
//
//	        // Assert that an IdNotFoundException is thrown
//	        assertThrows(IdNotFoundException.class, () -> applyService.getApplicationByUserId(1L));
//
//	        // Verify the repository interaction
//	        verify(applyRepository, times(1)).findByUserId(anyLong());
//	    }

	    // Test for updateApplication_NotFound
	    @Test
	    void testUpdateApplication_NotFound() {
	        // Mock the repository to return an empty Optional for the given user ID
	        when(applyRepository.findByUserId(anyLong())).thenReturn(Optional.empty());

	        // Assert that an IdNotFoundException is thrown
	        assertThrows(IdNotFoundException.class, () -> applyService.updateApplication(1L, applyDTO));

	        // Verify the repository interaction
	        verify(applyRepository, times(1)).findByUserId(anyLong());
	        verify(applyRepository, times(0)).save(any(Apply.class));
	    }

	    // Test for updateApplicationStatus - Successful status update
	    @Test
	    void testUpdateApplicationStatus_Success() throws IdNotFoundException {
	        // Mock the repository to return an application for the given user ID
	        when(applyRepository.findByUserId(anyLong())).thenReturn(Optional.of(apply));

	        // Mock the repository save method
	        when(applyRepository.save(any(Apply.class))).thenReturn(apply);

	        // Call the method
	        ApplyDTO result = applyService.updateApplicationStatus(1L, "approved");

	        // Assert that the application status is updated
	        assertNotNull(result);
	        assertEquals("approved", result.getStatus());

	        // Verify the repository interaction
	        verify(applyRepository, times(1)).findByUserId(anyLong());
	        verify(applyRepository, times(1)).save(any(Apply.class));
	    }

	    // Test for updateApplicationStatus - Application not found
	    @Test
	    void testUpdateApplicationStatus_NotFound() {
	        // Mock the repository to return an empty Optional for the given user ID
	        when(applyRepository.findByUserId(anyLong())).thenReturn(Optional.empty());

	        // Assert that an IdNotFoundException is thrown
	        assertThrows(IdNotFoundException.class, () -> applyService.updateApplicationStatus(1L, "approved"));

	        // Verify the repository interaction
	        verify(applyRepository, times(1)).findByUserId(anyLong());
	        verify(applyRepository, times(0)).save(any(Apply.class));
	    }

	    // Test for deleteApplication - Successful delete
	    @Test
	    void testDeleteApplication_Success() {
	        // Mock the repository to return an application for the given application ID
	        when(applyRepository.findById(anyLong())).thenReturn(Optional.of(apply));

	        // Call the method
	        boolean result = applyService.deleteApplication(1L);

	        // Assert that the result is true (application deleted successfully)
	        assertTrue(result);

	        // Verify the repository interaction
	        verify(applyRepository, times(1)).findById(anyLong());
	        verify(applyRepository, times(1)).deleteById(anyLong());
	    }

	    // Test for deleteApplication - Application not found
	    @Test
	    void testDeleteApplication_NotFound() {
	        // Mock the repository to return an empty Optional for the given application ID
	        when(applyRepository.findById(anyLong())).thenReturn(Optional.empty());

	        // Assert that an IdNotFoundException is thrown
	        assertThrows(IdNotFoundException.class, () -> applyService.deleteApplication(1L));

	        // Verify the repository interaction
	        verify(applyRepository, times(1)).findById(anyLong());
	        verify(applyRepository, times(0)).deleteById(anyLong());
	    }
}
